A Pen created at CodePen.io. You can find this one at http://codepen.io/chpecson/pen/oLWmKV.

 A Photo Gallery built with simplicity.